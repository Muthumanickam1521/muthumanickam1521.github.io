// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = 'Portfolio';
export const SITE_DESCRIPTION = 'Muthumanickam\'s tech professional';
export const GENERATE_SLUG_FROM_TITLE = true
export const TRANSITION_API = true